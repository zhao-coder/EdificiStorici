﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EdificiStorici.Model;
using Microsoft.AspNetCore.Authorization;

namespace EdificiStorici.Pages.Eventi
{
    [Authorize]
    public class IndexModel : PageModel
    {
        private IList<Evento> _EleEventidaDB = new List<Evento>() { }; // lista completa da DB

        [BindProperty]
        public IEnumerable<Evento> EleFinaleEventi { get; set; }
        
        public IndexModel()
        {
            #region 
            // leggo l'elenco dei dati dal DB e lo inserisco in _EleEventidaDB
            var connection = new System.Data.SQLite.SQLiteConnection("Data Source=Database//Edificidb.db; Version=3; New=false; Compress=True;");
            connection.Open();
            var cmd = new System.Data.SQLite.SQLiteCommand("select * from Evento", connection);
            var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                var nuovoEvento = new Evento()
                {
                    IdEdificio = (dr["IdEdificio"].ToString()),
                    luogoEdificio = dr["luogoEdificio"].ToString(),
                    nomeEdificio = dr["nomeEdificio"].ToString(),
                    anno = dr["anno"].ToString(),
                    stato = dr["stato"].ToString()
                };
                _EleEventidaDB.Add(nuovoEvento);
            }
            dr.Close();
            connection.Close();
            //fine attività su DB
            #endregion
        }

        public IActionResult OnGet()
        {
            EleFinaleEventi = _EleEventidaDB.ToList<Evento>();
            
            if (EleFinaleEventi.Count() == 0)
            {
                return NotFound();
            }
            return Page();
        }
        public IActionResult OnPost(string luogoScelto)
        {
            //prepare la bind property
            EleFinaleEventi = _EleEventidaDB.Where(e => e.luogoEdificio == luogoScelto);

            if (EleFinaleEventi.Count() == 0)
            {
                return NotFound();
            }
            return Page();
        }
    }
}

