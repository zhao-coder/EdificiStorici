﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EdificiStorici.Model;

namespace EdificiStorici.Pages.Eventi
{
    public class DetailsModel : PageModel
    {
        private IList<Evento> _EleEventidaDB = new List<Evento>() { }; // lista completa da DB

        [BindProperty]
        public Evento EventoDaMostrare { get; set; }

        public DetailsModel()
        {
            #region 
            // leggo l'elenco dei dati dal DB e lo inserisco in _EleEventidaDB
            var connection = new System.Data.SQLite.SQLiteConnection("Data Source=Database//Edificidb.db; Version=3; New=false; Compress=True;");
            connection.Open();
            var cmd = new System.Data.SQLite.SQLiteCommand("select * from Evento", connection);
            var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                var nuovoEvento = new Evento()
                {
                    IdEdificio = (dr["IdEdificio"].ToString()),
                    luogoEdificio = dr["luogoEdificio"].ToString(),
                    nomeEdificio = dr["nomeEdificio"].ToString(),
                    anno = dr["anno"].ToString(),
                    stato = dr["stato"].ToString()
                };
                _EleEventidaDB.Add(nuovoEvento);
            }
            dr.Close();
            connection.Close();
            //fine attività su DB
            #endregion
        }

        public IActionResult OnGet(string id)
        {
            if(id == null)
            {
                return NotFound();
            }

            EventoDaMostrare = _EleEventidaDB.FirstOrDefault(e => e.IdEdificio == id);

            return Page();
        }
    }
}

