﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EdificiStorici.Model;

namespace EdificiStorici.Pages.Eventi
{
    public class EditModel : PageModel
    {
        private IList<Evento> _EleEventidaDB = new List<Evento>() { }; // lista completa da DB
        public EditModel()
        {
            #region 
            // leggo l'elenco dei dati dal DB e lo inserisco in _EleEventidaDB
            var connection = new System.Data.SQLite.SQLiteConnection("Data Source=Database//Edificidb.db; Version=3; New=false; Compress=True;");
            connection.Open();
            var cmd = new System.Data.SQLite.SQLiteCommand("select * from Evento", connection);
            var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                var nuovoEvento = new Evento()
                {
                    IdEdificio = (dr["IdEdificio"].ToString()),
                    luogoEdificio = dr["luogoEdificio"].ToString(),
                    nomeEdificio = dr["nomeEdificio"].ToString(),
                    anno = dr["anno"].ToString(),
                    stato = dr["stato"].ToString()
                };
                _EleEventidaDB.Add(nuovoEvento);
            }
            dr.Close();
            connection.Close();
            //fine attività su DB
            #endregion
        }

        [BindProperty]
        public Evento EventoDaModificare { get; set; }

        public IActionResult OnGet(string id)
        {
            // -------- si controllano i parametri in ingresso
            if (id == null)
            {
                return NotFound();
            }

            EventoDaModificare = _EleEventidaDB.FirstOrDefault(m => m.IdEdificio == id);

            if(EventoDaModificare == null)
            {
                return NotFound();
            }

            return Page();
        }

        public IActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                return Page();
            }

            //------------------------ Azioni su DB
            var connection = new System.Data.SQLite.SQLiteConnection("Data Source=Database\\Edificidb.db; Version=3; New=False; Compress=True;");
            connection.Open();
            var cmd = new System.Data.SQLite.SQLiteCommand("Update Evento set luogoEdificio=@luogoEdificio, nomeEdificio=@nomeEdificio, stato=@stato, anno=@anno where IdEdificio=@IdEdificio", connection);
            cmd.Parameters.AddWithValue("@IdEdificio", int.Parse(EventoDaModificare.IdEdificio));
            cmd.Parameters.AddWithValue("@luogoEdificio", EventoDaModificare.luogoEdificio);
            cmd.Parameters.AddWithValue("@nomeEdificio", EventoDaModificare.nomeEdificio);
            cmd.Parameters.AddWithValue("@Anno", EventoDaModificare.anno);
            cmd.Parameters.AddWithValue("@Stato", EventoDaModificare.stato);
            int nr = cmd.ExecuteNonQuery();
            connection.Close();
            //-----------------------------
            if (nr == 0)
            {
                return NotFound();
            }

            return RedirectToPage("./index");
        }
    }
}